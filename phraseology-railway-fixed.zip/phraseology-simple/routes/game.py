from flask import Blueprint, jsonify, request
import random
import string
import threading
import time
from datetime import datetime, timedelta

game_bp = Blueprint('game', __name__)

# In-memory game storage
games = {}

# Sample terms database
sample_terms = [
    {
        "term": "The Confused Flamingo",
        "real_definition": "When someone stands on one leg during intimate moments, looking around confused like they forgot what they were supposed to be doing.",
        "difficulty": "medium"
    },
    {
        "term": "The Awkward Penguin", 
        "real_definition": "When you waddle around naked trying to find your clothes after an unexpected encounter.",
        "difficulty": "mild"
    },
    {
        "term": "The WiFi Password",
        "real_definition": "When you have to ask someone to repeat what they just whispered in your ear during intimate moments.",
        "difficulty": "spicy"
    },
    {
        "term": "The Netflix Buffer",
        "real_definition": "When things get interrupted just as they're getting good, leaving everyone hanging.",
        "difficulty": "mild"
    },
    {
        "term": "The Bluetooth Connection",
        "real_definition": "When you're trying to sync up with your partner but keep losing the connection.",
        "difficulty": "medium"
    },
    {
        "term": "The Loading Screen",
        "real_definition": "When you're both ready to go but someone needs a moment to 'prepare' first.",
        "difficulty": "mild"
    },
    {
        "term": "The Pop-up Blocker",
        "real_definition": "When someone keeps interrupting just as things are getting interesting.",
        "difficulty": "medium"
    },
    {
        "term": "The Autocorrect Fail",
        "real_definition": "When you say something completely different from what you meant during intimate conversation.",
        "difficulty": "mild"
    },
    {
        "term": "The Airplane Mode",
        "real_definition": "When someone completely disconnects and goes silent during intimate moments.",
        "difficulty": "spicy"
    },
    {
        "term": "The Software Update",
        "real_definition": "When someone suddenly wants to try something completely new and different.",
        "difficulty": "medium"
    },
    {
        "term": "The Spam Filter",
        "real_definition": "When someone is very selective about what kind of attention they'll accept.",
        "difficulty": "spicy"
    },
    {
        "term": "The Cookie Settings",
        "real_definition": "When you have to negotiate what you're both comfortable with beforehand.",
        "difficulty": "medium"
    },
    {
        "term": "The Incognito Mode",
        "real_definition": "When someone pretends they don't remember what happened the night before.",
        "difficulty": "spicy"
    },
    {
        "term": "The Refresh Button",
        "real_definition": "When you need to start over because something went wrong the first time.",
        "difficulty": "mild"
    },
    {
        "term": "The Caps Lock",
        "real_definition": "When someone gets way too enthusiastic and loud during intimate moments.",
        "difficulty": "medium"
    },
    {
        "term": "The Ctrl+Z",
        "real_definition": "When you immediately regret something you just did and wish you could undo it.",
        "difficulty": "spicy"
    },
    {
        "term": "The Low Battery Warning",
        "real_definition": "When someone starts losing energy and enthusiasm halfway through.",
        "difficulty": "mild"
    },
    {
        "term": "The Screensaver",
        "real_definition": "When someone zones out and stares blankly during intimate moments.",
        "difficulty": "medium"
    },
    {
        "term": "The Virus Scan",
        "real_definition": "When someone is very thorough about checking everything before proceeding.",
        "difficulty": "spicy"
    },
    {
        "term": "The System Crash",
        "real_definition": "When everything stops working suddenly and unexpectedly.",
        "difficulty": "medium"
    },
    {
        "term": "The Password Reset",
        "real_definition": "When you have to start completely over with someone you've been with before.",
        "difficulty": "spicy"
    },
    {
        "term": "The Backup Drive",
        "real_definition": "When someone keeps a secret stash of intimate photos or messages.",
        "difficulty": "spicy"
    }
]

def generate_room_code():
    """Generate a unique 4-character room code"""
    while True:
        code = ''.join(random.choices(string.ascii_uppercase, k=4))
        if code not in games:
            return code

def get_random_term(difficulty="random"):
    """Get a random term based on difficulty"""
    if difficulty == "random":
        return random.choice(sample_terms)
    else:
        filtered_terms = [term for term in sample_terms if term["difficulty"] == difficulty]
        return random.choice(filtered_terms) if filtered_terms else random.choice(sample_terms)

def cleanup_old_games():
    """Remove abandoned games to prevent memory overload"""
    while True:
        current_time = datetime.now()
        games_to_remove = []
        
        for room_code, game in games.items():
            game_age = current_time - game.get('created_at', current_time)
            
            # Only remove games that are truly abandoned (in lobby state for too long)
            if game.get('game_state') == 'lobby' and len(game['players']) == 1 and game_age > timedelta(hours=1):
                games_to_remove.append(room_code)
            
            # Remove very old games (24 hours) regardless of state
            elif game_age > timedelta(hours=24):
                games_to_remove.append(room_code)
        
        for room_code in games_to_remove:
            del games[room_code]
            print(f"Cleaned up abandoned game: {room_code}")
        
        time.sleep(1800)  # Run cleanup every 30 minutes (less frequent)

# Start cleanup thread
cleanup_thread = threading.Thread(target=cleanup_old_games, daemon=True)
cleanup_thread.start()

def calculate_scores(game, votes):
    """Calculate and update scores for the current round"""
    round_scores = {}
    
    for player in game['players']:
        player_id = player['id']
        player_name = player['name']
        round_points = 0
        
        # Points for correct guess (voting for real definition)
        if votes.get(player_id) == 'real':
            round_points += 10
        
        # Points for fooling others (others voting for your fake definition)
        for voter_id, vote in votes.items():
            if vote == player_id and voter_id != player_id:
                round_points += 5
        
        # Update player's total score
        player['score'] += round_points
        round_scores[player_name] = round_points
    
    return round_scores

@game_bp.route('/test', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'success': True,
        'message': 'PhЯaseology API is running!',
        'active_games': len(games)
    })

@game_bp.route('/create-game', methods=['POST'])
def create_game():
    """Create a new game room"""
    data = request.json
    
    room_code = generate_room_code()
    host_name = data.get('host_name', 'Host')
    difficulty = data.get('difficulty', 'random')
    max_rounds = data.get('max_rounds', 5)
    
    # Create new game
    games[room_code] = {
        'room_code': room_code,
        'host': host_name,
        'players': [{'name': host_name, 'id': f'player_{len(games)}_{0}', 'score': 0}],
        'difficulty': difficulty,
        'max_rounds': max_rounds,
        'current_round': 0,
        'game_state': 'lobby',
        'current_term': None,
        'definitions': [],
        'votes': {},
        'round_scores': {},
        'created_at': datetime.now()
    }
    
    return jsonify({
        'success': True,
        'room_code': room_code,
        'game': games[room_code]
    })

@game_bp.route('/join-game', methods=['POST'])
def join_game():
    """Join an existing game room"""
    data = request.json
    room_code = data.get('room_code', '').upper()
    player_name = data.get('player_name', 'Player')
    
    if room_code not in games:
        return jsonify({'success': False, 'error': 'Game not found'}), 404
    
    game = games[room_code]
    
    if game['game_state'] != 'lobby':
        return jsonify({'success': False, 'error': 'Game already in progress'}), 400
    
    # Check if player name already exists
    existing_names = [player['name'] for player in game['players']]
    if player_name in existing_names:
        return jsonify({'success': False, 'error': 'Player name already taken'}), 400
    
    # Add player to game
    player_id = f'player_{room_code}_{len(game["players"])}'
    game['players'].append({'name': player_name, 'id': player_id, 'score': 0})
    
    return jsonify({
        'success': True,
        'game': game,
        'player_id': player_id
    })

@game_bp.route('/start-game', methods=['POST'])
def start_game():
    """Start the game (host only)"""
    data = request.json
    room_code = data.get('room_code', '').upper()
    
    if room_code not in games:
        return jsonify({'success': False, 'error': 'Game not found'}), 404
    
    game = games[room_code]
    
    if len(game['players']) < 2:
        return jsonify({'success': False, 'error': 'Need at least 2 players to start'}), 400
    
    # Start first round
    game['current_round'] = 1
    game['game_state'] = 'writing'
    game['current_term'] = get_random_term(game['difficulty'])
    game['definitions'] = []
    game['votes'] = {}
    
    return jsonify({
        'success': True,
        'game': game
    })

@game_bp.route('/submit-definition', methods=['POST'])
def submit_definition():
    """Submit a player's fake definition"""
    try:
        data = request.json
        room_code = data.get('room_code', '').upper()
        player_id = data.get('player_id')
        definition_text = data.get('definition', '').strip()
        
        if room_code not in games:
            return jsonify({'success': False, 'error': 'Game not found'}), 404
        
        game = games[room_code]
        
        if game['game_state'] != 'writing':
            return jsonify({'success': False, 'error': 'Not in writing phase'}), 400
        
        if not definition_text:
            return jsonify({'success': False, 'error': 'Definition cannot be empty'}), 400
        
        # Find player name
        player_name = None
        for player in game['players']:
            if player['id'] == player_id:
                player_name = player['name']
                break
        
        if not player_name:
            return jsonify({'success': False, 'error': 'Player not found'}), 404
        
        # Check if player already submitted
        for definition in game['definitions']:
            if definition.get('author') == player_name:
                return jsonify({'success': False, 'error': 'Definition already submitted'}), 400
        
        # Add definition
        game['definitions'].append({
            'text': definition_text,
            'author': player_name,
            'is_real': False
        })
        
        # Check if all players have submitted
        if len(game['definitions']) == len(game['players']):
            # Add real definition and shuffle
            game['definitions'].append({
                'text': game['current_term']['real_definition'],
                'author': 'Real',
                'is_real': True
            })
            random.shuffle(game['definitions'])
            game['game_state'] = 'voting'
        
        return jsonify({
            'success': True,
            'game': game
        })
    except Exception as e:
        return jsonify({'success': False, 'error': f'Server error: {str(e)}'}), 500

@game_bp.route('/submit-vote', methods=['POST'])
def submit_vote():
    """Submit a player's vote"""
    try:
        data = request.json
        room_code = data.get('room_code', '').upper()
        player_id = data.get('player_id')
        vote_index = data.get('vote_index')
        
        if room_code not in games:
            return jsonify({'success': False, 'error': 'Game not found'}), 404
        
        game = games[room_code]
        
        if game['game_state'] != 'voting':
            return jsonify({'success': False, 'error': 'Not in voting phase'}), 400
        
        if vote_index < 0 or vote_index >= len(game['definitions']):
            return jsonify({'success': False, 'error': 'Invalid vote'}), 400
        
        # Record vote
        voted_definition = game['definitions'][vote_index]
        if voted_definition['is_real']:
            game['votes'][player_id] = 'real'
        else:
            # Find the author's player ID
            author_name = voted_definition['author']
            for player in game['players']:
                if player['name'] == author_name:
                    game['votes'][player_id] = player['id']
                    break
        
        # Check if all players have voted
        if len(game['votes']) == len(game['players']):
            # Calculate scores and move to results
            try:
                game['round_scores'] = calculate_scores(game, game['votes'])
                game['game_state'] = 'results'
            except Exception as score_error:
                return jsonify({'success': False, 'error': f'Scoring error: {str(score_error)}'}), 500
        
        return jsonify({
            'success': True,
            'game': game
        })
    except Exception as e:
        return jsonify({'success': False, 'error': f'Vote error: {str(e)}'}), 500

@game_bp.route('/next-round', methods=['POST'])
def next_round():
    """Progress to next round or finish game"""
    try:
        data = request.json
        room_code = data.get('room_code', '').upper()
        
        if room_code not in games:
            return jsonify({'success': False, 'error': 'Game not found'}), 404
        
        game = games[room_code]
        
        if game['game_state'] != 'results':
            return jsonify({'success': False, 'error': 'Not in results phase'}), 400
        
        if game['current_round'] >= game['max_rounds']:
            # Game finished
            game['game_state'] = 'finished'
            # Sort players by score for final leaderboard
            game['players'].sort(key=lambda x: x['score'], reverse=True)
        else:
            # Start next round
            game['current_round'] += 1
            game['game_state'] = 'writing'
            try:
                game['current_term'] = get_random_term(game['difficulty'])
            except Exception as term_error:
                return jsonify({'success': False, 'error': f'Term selection error: {str(term_error)}'}), 500
            game['definitions'] = []
            game['votes'] = {}
            game['round_scores'] = {}
        
        return jsonify({
            'success': True,
            'game': game
        })
    except Exception as e:
        return jsonify({'success': False, 'error': f'Next round error: {str(e)}'}), 500

@game_bp.route('/player-definitions/<room_code>', methods=['GET'])
def get_player_definitions(room_code):
    """Get mapping of which definitions belong to which players"""
    room_code = room_code.upper()
    if room_code not in games:
        return jsonify({'success': False, 'error': 'Game not found'}), 404
    
    game = games[room_code]
    player_definitions = {}
    
    for definition in game.get('definitions', []):
        if not definition.get('is_real', False):
            player_definitions[definition['text']] = definition['author']
    
    return jsonify({
        'success': True,
        'player_definitions': player_definitions
    })

@game_bp.route('/game-state/<room_code>', methods=['GET'])
def get_game_state(room_code):
    """Get current game state"""
    room_code = room_code.upper()
    if room_code not in games:
        return jsonify({'success': False, 'error': 'Game not found'}), 404
    
    return jsonify({
        'success': True,
        'game': games[room_code]
    })

